<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <!-- Header com um link pra página inicial -->
    <a href="index.php">Página Inicial</a>
    <hr>
</body>
</html>